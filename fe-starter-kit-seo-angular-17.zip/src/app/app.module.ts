import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PublishersLandingPageComponent } from './components/publishers-landing-page/publishers-landing-page.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/common/navbar/navbar.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { NotFoundComponent } from './components/common/not-found/not-found.component';
import { SignInComponent } from './components/auth/sign-in/sign-in.component';
import { SignUpComponent } from './components/auth/sign-up/sign-up.component';
import { AboutUsComponent } from './components/common/about-us/about-us.component';
import { PrivacyPolicyComponent } from './components/common/privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './components/common/terms-and-conditions/terms-and-conditions.component';
import { ContactUsComponent } from './components/common/contact-us/contact-us.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonService } from './helper/services/common-services/common.service';

@NgModule({
  declarations: [
    AppComponent,
    PublishersLandingPageComponent,
    HomeComponent,
    NavbarComponent,
    FooterComponent,
    NotFoundComponent,
    SignInComponent,
    SignUpComponent,
    AboutUsComponent,
    PrivacyPolicyComponent,
    TermsAndConditionsComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [
    provideClientHydration(),
    CommonService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
