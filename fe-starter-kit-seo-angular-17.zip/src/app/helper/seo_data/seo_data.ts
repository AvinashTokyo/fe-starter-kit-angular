class SEOData {

  robots: string = `index, follow`;
  author: string = `BacklinkWizard`;

  data: any = {

    // English
    en: {

      // Home Page
      home: {
        title: `BacklinkWizard | Ultimate Tool for High-Quality Backlinks & SEO Success`,
        description: `Boost your website’s SEO with Backlink Wizard! Discover powerful tools for generating high-quality backlinks, improving your search rankings, and driving organic traffic. Get started today and transform your SEO strategy!`,
        robots: this.robots,
        author: this.author,
      },

      // About Us Page
      about_us: {
        title: `About Us | BacklinkWizard - Meet Our Expert Team & Learn Our Mission`,
        description: `Discover Backlink Wizard’s mission and meet the expert team behind our powerful SEO tools. Learn about our commitment to helping you boost your website’s search rankings with high-quality backlinks. Join us on our journey to SEO success!`,
        robots: this.robots,
        author: this.author,
      },

      // Contact Us Page
      contact_us: {
        title: "Contact Us | BacklinkWizard - Get in Touch with Our SEO Experts",
        description: "Have questions or need assistance? Contact Backlink Wizard’s expert team for support with our SEO tools, backlink strategies, and more. We're here to help you achieve SEO success. Reach out to us today!",
        robots: this.robots,
        author: this.author,
      },

      // Privacy Policy Page
      privacy_policy: {
        title: "Privacy Policy | BacklinkWizard - Your Privacy is Our Priority",
        description: "Learn how Backlink Wizard protects your privacy. Read our comprehensive privacy policy to understand how we collect, use, and safeguard your information. Your trust is important to us",
        robots: this.robots,
        author: this.author,
      },

      // Terms And Conditions Page
      terms_and_conditions: {
        title: "Terms and Conditions | BacklinkWizard - Understand Our Service Terms",
        description: "Read the terms and conditions of using Backlink Wizard. Understand your rights and obligations when using our SEO tools and services. Stay informed and ensure compliance with our guidelines",
        robots: this.robots,
        author: this.author,
      },

      // Sign In Page
      sign_in: {
        title: "Sign In | BacklinkWizard - Access Your SEO Tools and Dashboard",
        description: "Sign in to Backlink Wizard to access your personalized SEO tools and dashboard. Manage your backlink strategies, track your progress, and optimize your website’s search performance",
        robots: this.robots,
        author: this.author,
      },

      // Sign Up Page
      sign_up: {
        title: "Sign Up | BacklinkWizard - Create Your Account for SEO Success",
        description: "Sign up for Backlink Wizard and gain access to powerful SEO tools and resources. Start optimizing your website’s search performance and building high-quality backlinks today",
        robots: this.robots,
        author: this.author,
      },
    }

  };

  defaultData: any = {
    home: this.data.en.home,

    about_us: this.data.en.about_us,
    contact_us: this.data.en.contact_us,
    privacy_policy: this.data.en.privacy_policy,
    terms_and_conditions: this.data.en.terms_and_conditions,

    sign_in: this.data.en.sign_in,
    sign_up: this.data.en.sign_up,
  };
}

export default new SEOData();


// SEO Chat GPT Information
/*
Creating effective SEO content for your website, BacklinkWizard.com, involves crafting an SEO title, meta description, and optimizing other key elements. Here’s a detailed SEO package to enhance your website’s search engine visibility:

SEO Title and Meta Description
SEO Title:
Backlink Wizard | Ultimate Tool for High-Quality Backlinks & SEO Success

Meta Description:
Boost your website’s SEO with Backlink Wizard! Discover powerful tools for generating high-quality backlinks, improving your search rankings, and driving organic traffic. Get started today and transform your SEO strategy!

Keywords
Backlink Generator
SEO Tools
High-Quality Backlinks
SEO Success
Organic Traffic
Link Building
SEO Strategy
Search Engine Optimization
Header Tags (H1, H2, H3)
H1:

Unlock Your SEO Potential with Backlink Wizard
H2:

Why Backlinks Matter for SEO
Features of Backlink Wizard
How to Generate Quality Backlinks
User Testimonials
Get Started with Backlink Wizard
H3:

Understanding Backlinks
Boost Your Search Rankings
Drive Organic Traffic
Easy-to-Use Tools
Success Stories
FAQs
On-Page SEO
Content Optimization:

Ensure your content is valuable, informative, and includes target keywords naturally.
Use keyword variations and long-tail keywords to cover different search intents.
Internal Linking:

Link to other relevant pages on your website to keep visitors engaged and reduce bounce rates.
Image Optimization:

Use descriptive file names and alt text for images that include relevant keywords.
Mobile Optimization:

Ensure your website is mobile-friendly and loads quickly on all devices.
Off-Page SEO
Backlink Building:

Reach out to relevant websites and blogs for guest posting opportunities.
Submit your website to relevant directories and business listings.
Social Media Engagement:

Share your content on social media platforms to drive traffic and increase visibility.
Engage with your audience to build a community around your brand.
Influencer Outreach:

Collaborate with influencers in your industry to gain exposure and build authority.
Technical SEO
Site Speed:

Optimize your website’s loading speed by compressing images, leveraging browser caching, and minimizing JavaScript.
XML Sitemap:

Create and submit an XML sitemap to search engines to ensure all your pages are indexed.
Robots.txt:

Ensure your robots.txt file is correctly configured to guide search engine crawlers.
SSL Certificate:

Make sure your website uses HTTPS for a secure browsing experience, which is favored by search engines.
Local SEO (if applicable)
Google My Business:

Create and optimize a Google My Business profile to appear in local search results.
Local Keywords:

Include local keywords if your services are geographically targeted.
Customer Reviews:

Encourage satisfied customers to leave positive reviews on your Google My Business profile and other review platforms.
By implementing these SEO strategies, you can improve your website's visibility, drive more organic traffic, and achieve better search engine rankings.
*/
