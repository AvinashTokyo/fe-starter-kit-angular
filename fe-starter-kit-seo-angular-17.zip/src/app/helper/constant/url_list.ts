const url_list = {
  home: '/',

  about_us: '/about-us',
  contact_us: '/contact-us',
  privacy_policy: '/privacy-policy',
  terms_and_conditions: '/terms-and-conditions',

  sign_in: '/auth/sign-in',
  sign_up: '/auth/sign-up',
}

export default url_list;
