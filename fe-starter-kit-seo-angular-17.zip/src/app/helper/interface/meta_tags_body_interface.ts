export type MetaTagsBodyInterface = {
  title?: string,
  description?: string,
  keywords?: string,
  robots?: string,
  author?: string,

  og_title?: string,
  og_description?: string,
  og_image?: string,
  og_url?: string,

  twitter_card?: string,
  twitter_title?: string,
  twitter_description?: string,
  twitter_image?: string,

}
