import { Component, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Renderer2 } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs';
import { Meta, Title } from '@angular/platform-browser';
import { MetaTagsBodyInterface } from './helper/interface/meta_tags_body_interface';
import seo_data from './helper/seo_data/seo_data';
import url_list from './helper/constant/url_list';
import { environment } from '../environments/environment';
import { CommonService } from './helper/services/common-services/common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  // title = 'backlinkwizard';

  // mailto = `mailto:numitrex@gmail.com?subject=Request%20for%20Backlink/Guest%20Post%20Collaboration&body=Hello,%0A%0AI hope this email finds you well.%0A%0AI'm reaching out to express my interest in collaborating with your esteemed website. As I explore opportunities to enhance my website's online presence, I am particularly keen on acquiring a backlink/guest post from your platform.%0A%0AYour website's authority and relevance align perfectly with my goals, and I believe that a collaboration between our platforms could mutually benefit both parties. %0A%0ACould you please provide me with more information on the process for securing a backlink/guest post on your website? I am eager to discuss potential opportunities and explore how we can work together to achieve our respective objectives.%0A%0ALooking forward to your response.%0A%0ABest regards,%0A[Your Name]%0A[Your Website/Business Name]%0A[Your Contact Information]`

  currentUrl!: string | any;
  currentLanguage: string | any;
  defaultLanguage: string | any = environment?.default_language ?? 'en';
  private routerSubscription!: Subscription;

  constructor(
    private router: Router,
    private metaService: Meta,
    private titleService: Title,
    @Inject(DOCUMENT) private document: Document,
    private renderer2: Renderer2,
    private commonService: CommonService,
  ) { }

  ngOnInit() {
    // Subscribe to the router events
    this.routerSubscription = this.router.events.pipe(
      filter((event: any) => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd | any) => {
      console.log('Route changed to:', event.urlAfterRedirects);

      // remove ?lang= from url all query params
      // this.currentUrl = this.currentUrl.replace(/\?lang=[^&]*/, '');
      this.currentUrl = event.urlAfterRedirects.split('?')[0];
      console.log(this.currentUrl, "currentUrl");


      // get lang from query params
      this.currentLanguage = this.router.parseUrl(event.urlAfterRedirects).queryParams['lang'];
      if (!this.currentLanguage) {
        this.currentLanguage = this.defaultLanguage;
      }

      this.loadSEO();
    });
  }

  ngOnDestroy() {
    // Unsubscribe to prevent memory leaks
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  loadSEO() {
    switch (this.currentUrl) {

      // Home Page = '/'
      case url_list.home:
        this.seoAPICall('home', url_list.home);
        break;

      // About Us Page = '/about-us'
      case url_list.about_us:
        this.seoAPICall('about_us', url_list.about_us);
        break;

      // Contact Us Page = '/contact-us'
      case url_list.contact_us:
        this.seoAPICall('contact_us', url_list.contact_us);
        break;

      // Privacy Policy Page = '/privacy-policy'
      case url_list.privacy_policy:
        this.seoAPICall('privacy_policy', url_list.privacy_policy);
        break;

      // Terms and Conditions Page = '/terms-and-conditions'
      case url_list.terms_and_conditions:
        this.seoAPICall('terms_and_conditions', url_list.terms_and_conditions);
        break;

      // Sign In Page = '/auth/sign-in'
      case url_list.sign_in:
        this.seoAPICall('sign_in', url_list.sign_in);
        break;

      // Sign Up Page = '/auth/sign-up'
      case url_list.sign_up:
        this.seoAPICall('sign_up', url_list.sign_up);
        break;


      // Default
      default:
        this.setMetaTags(seo_data.data?.[this.currentLanguage]?.home, 'home', url_list.home);
        break;
    }
  }

  setMetaTags(body: MetaTagsBodyInterface, slug: string, route: string) {
    this.titleService.setTitle(body?.title ?? seo_data.defaultData?.[slug].title);

    this.metaService.addTags([
      { name: 'description', content: body?.description ?? seo_data.defaultData?.[slug].description },

      // { name: 'keywords', content: body?.keywords },

      { name: 'robots', content: body?.robots ?? seo_data.defaultData?.[slug].robots },
      { name: 'author', content: body?.author ?? seo_data.defaultData?.[slug].author },

      { property: 'og:title', content: body?.title ?? seo_data.defaultData?.[slug].title },
      { property: 'og:description', content: body?.description ?? seo_data.defaultData?.[slug].description },
      // { property: 'og:image', content: 'URL to your image' },
      // { property: 'og:url', content: 'URL to your page' },

      // { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: body?.title ?? seo_data.defaultData?.[slug].title },
      { name: 'twitter:description', content: body?.description ?? seo_data.defaultData?.[slug].description },
      // { name: 'twitter:image', content: 'URL to your Twitter image' }
    ]);

    const script = this.renderer2.createElement('script');
    script.type = 'application/ld+json';
    script.text = `
      {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": ${body?.title ?? seo_data.defaultData?.[slug].title},
        "description": ${body?.description ?? seo_data.defaultData?.[slug].description},
        "url": ${environment.website_url}${route}
      }
    `;
    this.renderer2.appendChild(this.document.head, script);
  }

  // setStructuredData(body: MetaTagsBodyInterface, slug: string, route: string) {
  //   const script = this.renderer2.createElement('script');
  //   script.type = 'application/ld+json';
  //   script.text = `
  //     {
  //       "@context": "https://schema.org",
  //       "@type": "WebPage",
  //       "name": ${body?.title ?? seo_data.defaultData?.[slug].title},
  //       "description": ${seo_data.defaultData?.[slug].description},
  //       "url": ${environment.website_url}${route}
  //     }
  //   `;
  //   this.renderer2.appendChild(this.document.head, script);
  // }

  seoAPICall(slug: string, url: string) {
    this.commonService.getSeoDataByLanguage(slug, this.currentLanguage).pipe()
      .subscribe({
        next: (data: any) => {
          console.log(data, "data in seoAPICall");
          this.setMetaTags(data, slug, url);
        },
        error: (error: any) => {
          console.error(error, "Error in seoAPICall");
        }
      })
  }
}
