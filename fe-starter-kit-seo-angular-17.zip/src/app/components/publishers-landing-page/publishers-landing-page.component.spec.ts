import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublishersLandingPageComponent } from './publishers-landing-page.component';

describe('PublishersLandingPageComponent', () => {
  let component: PublishersLandingPageComponent;
  let fixture: ComponentFixture<PublishersLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PublishersLandingPageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PublishersLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
