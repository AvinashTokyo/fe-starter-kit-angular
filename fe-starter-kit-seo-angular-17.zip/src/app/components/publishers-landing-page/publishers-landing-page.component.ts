import { Component } from '@angular/core';

@Component({
  selector: 'app-publishers-landing-page',
  templateUrl: './publishers-landing-page.component.html',
  styleUrl: './publishers-landing-page.component.scss'
})
export class PublishersLandingPageComponent {

}
