import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PublishersLandingPageComponent } from './components/publishers-landing-page/publishers-landing-page.component';
import { HomeComponent } from './components/home/home.component';
import { SignInComponent } from './components/auth/sign-in/sign-in.component';
import { SignUpComponent } from './components/auth/sign-up/sign-up.component';
import { AboutUsComponent } from './components/common/about-us/about-us.component';
import { ContactUsComponent } from './components/common/contact-us/contact-us.component';
import { PrivacyPolicyComponent } from './components/common/privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './components/common/terms-and-conditions/terms-and-conditions.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'about-us',
    component: AboutUsComponent
  },
  {
    path: 'contact-us',
    component: ContactUsComponent
  },
  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent
  },
  {
    path: 'terms-and-conditions',
    component: TermsAndConditionsComponent
  },
  {
    path: 'auth',
    children: [
      {
        path: 'sign-in',
        component: SignInComponent
      },
      {
        path: "sign-up",
        component: SignUpComponent
      }
    ]
  },
  {
    path: "**",
    redirectTo: '',
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
