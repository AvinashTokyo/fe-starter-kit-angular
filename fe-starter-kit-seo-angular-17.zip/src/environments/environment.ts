export const environment = {
  production: false,

  default_language: 'en',
  website_url: `https://backlinkwizard.com`,
};
